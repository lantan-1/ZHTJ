// 全局组件类型声明
declare module 'element-plus';
declare module 'element-plus/dist/index.css';
declare module 'vue-router';
declare module 'axios';
declare module 'pinia'; 